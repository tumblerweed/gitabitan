#!/usr/bin/env python3
"""Gitabitan — গীতবিতান browser.

Usage: python serve.py [--port 8080] [--no-open]
"""

import argparse
import http.server
import json
import os
import socketserver
import sys
import urllib.parse
import urllib.request
import webbrowser


GOOGLE_API = "https://inputtools.google.com/request"


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        ".wasm": "application/wasm",
        ".json": "application/json",
        ".js": "application/javascript",
        ".css": "text/css",
        ".db": "application/octet-stream",
    }

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/api/transliterate":
            self._handle_transliterate(parsed)
        else:
            super().do_GET()

    def _handle_transliterate(self, parsed):
        qs = urllib.parse.parse_qs(parsed.query)
        text = qs.get("t", [""])[0]
        num = qs.get("num", ["5"])[0]

        if not text:
            self._json_response({"candidates": [], "source": "empty"})
            return

        try:
            params = urllib.parse.urlencode({
                "text": text, "itc": "bn-t-i0-und", "num": num
            })
            url = f"{GOOGLE_API}?{params}"
            req = urllib.request.Request(url, headers={"User-Agent": "Gitabitan/1.0"})
            with urllib.request.urlopen(req, timeout=3) as resp:
                data = json.loads(resp.read().decode())

            if data[0] == "SUCCESS" and data[1]:
                candidates = data[1][0][1]
                self._json_response({"candidates": candidates, "source": "google"})
            else:
                self._json_response({"candidates": [], "source": "google-empty"})
        except Exception:
            # Network error — let the client handle offline fallback
            self._json_response({"candidates": [], "source": "error"}, status=503)

    def _json_response(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(body)

    def end_headers(self):
        # Only add no-cache for non-API responses (API sets its own headers)
        if not hasattr(self, '_headers_sent_by_api'):
            self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def log_message(self, format, *args):
        # Quieter logging
        if args and "200" not in str(args[1:2]):
            super().log_message(format, *args)


def main():
    parser = argparse.ArgumentParser(description="Serve the Gitabitan web app")
    parser.add_argument("--port", type=int, default=8080, help="Port to serve on (default: 8080)")
    parser.add_argument("--no-open", action="store_true", help="Don't open browser automatically")
    args = parser.parse_args()

    # Serve from the directory where this script lives
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    with socketserver.TCPServer(("", args.port), Handler) as httpd:
        url = f"http://localhost:{args.port}"
        print(f"\n  গীতবিতান — Gitabitan Browser")
        print(f"  Serving at {url}")
        print(f"  Press Ctrl+C to stop\n")

        if not args.no_open:
            webbrowser.open(url)

        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopped.")
            sys.exit(0)


if __name__ == "__main__":
    main()
